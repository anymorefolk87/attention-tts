import argparse,json,torch
from torch.utils.data import DataLoader
from aha_tts.data import SyntheticTTSDataset,collate_tts
from aha_tts.model import AdaptiveHybridTacotron
from aha_tts.losses import TacotronLoss
from aha_tts.metrics import alignment_metrics

p=argparse.ArgumentParser(); p.add_argument("--epochs",type=int,default=1); p.add_argument("--config",default="config.json")
args=p.parse_args(); cfg=json.load(open(args.config))
torch.manual_seed(cfg["seed"])
dev="cuda" if torch.cuda.is_available() else "cpu"
ds=SyntheticTTSDataset(16,cfg["vocab_size"],cfg["n_mels"])
dl=DataLoader(ds,batch_size=cfg["batch_size"],shuffle=True,collate_fn=collate_tts)
model=AdaptiveHybridTacotron(**{k:cfg[k] for k in [
"vocab_size","embedding_dim","encoder_dim","decoder_dim","attention_dim","n_mels",
"prenet_dim","postnet_channels","max_decoder_steps","gate_threshold"]}).to(dev)
lossfn=TacotronLoss(); opt=torch.optim.Adam(model.parameters(),lr=cfg["learning_rate"])
for ep in range(args.epochs):
    for b in dl:
        tok=b["tokens"].to(dev); tl=b["token_lengths"].to(dev); mel=b["mels"].to(dev)
        ml=b["mel_lengths"].to(dev); gt=b["gate_targets"].to(dev)
        opt.zero_grad(); out=model(tok,tl,mel); losses=lossfn(out,mel,gt,tl,ml)
        losses["total"].backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
    print("epoch",ep+1,"loss",round(losses["total"].item(),4),alignment_metrics(out["alignments"]))
torch.save(model.state_dict(),"adaptive_hybrid_tts.pt")
