# Controlled synthetic alignment benchmark

Reference command:

`python run_synthetic_benchmark.py --trials 200 --noise 1.25`

Previously observed output:

| Metric | Location-sensitive | Adaptive Hybrid |
|---|---:|---:|
| Backward-step rate | 0.3265 | 0.2934 |
| Large-jump rate | 0.0796 | 0.0516 |
| Mean absolute alignment error | 1.1528 | 1.0235 |
| Attention entropy | 1.4472 | 1.6199 |

These results evaluate controlled alignment behavior only.
