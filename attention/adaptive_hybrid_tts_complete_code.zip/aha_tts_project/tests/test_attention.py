import torch
from aha_tts.attention import AdaptiveHybridAttention
def test_normalized():
    m=AdaptiveHybridAttention(16,24,12); B,N=2,10
    q=torch.randn(B,24); k=torch.randn(B,N,16)
    p=torch.softmax(torch.randn(B,N),-1); c=p.clone(); ctx=torch.randn(B,16)
    a,l,al,am=m(q,k,p,c,ctx)
    assert a.shape==(B,N)
    assert torch.allclose(a.sum(-1),torch.ones(B),atol=1e-5)
    assert torch.all((l>=0)&(l<=1))
