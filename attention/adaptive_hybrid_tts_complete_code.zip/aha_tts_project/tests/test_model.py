import torch
from aha_tts.model import AdaptiveHybridTacotron
def test_shapes():
    m=AdaptiveHybridTacotron(vocab_size=64,embedding_dim=32,encoder_dim=32,decoder_dim=64,
        attention_dim=32,n_mels=16,prenet_dim=32,postnet_channels=32,max_decoder_steps=20)
    out=m(torch.randint(1,64,(2,10)),torch.tensor([10,8]),torch.randn(2,16,12))
    assert out["mel"].shape==(2,16,12)
    assert out["alignments"].shape==(2,12,10)
