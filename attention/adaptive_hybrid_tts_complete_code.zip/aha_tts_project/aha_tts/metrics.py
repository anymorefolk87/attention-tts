def alignment_metrics(a,max_forward_jump=3):
    peak=a.argmax(-1); d=peak[:,1:]-peak[:,:-1]
    return {
        "backward_rate":(d<0).float().mean().item(),
        "large_jump_rate":(d>max_forward_jump).float().mean().item(),
        "attention_entropy":(-(a*a.clamp_min(1e-9).log()).sum(-1)).mean().item()
    }
