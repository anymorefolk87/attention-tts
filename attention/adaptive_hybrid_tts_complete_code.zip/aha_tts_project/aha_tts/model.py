import torch
import torch.nn as nn
import torch.nn.functional as F
from .attention import AdaptiveHybridAttention

class Encoder(nn.Module):
    def __init__(self,vocab_size,embedding_dim,encoder_dim):
        super().__init__()
        self.embedding=nn.Embedding(vocab_size,embedding_dim,padding_idx=0)
        self.convs=nn.ModuleList()
        in_ch=embedding_dim
        for _ in range(3):
            self.convs.append(nn.Sequential(
                nn.Conv1d(in_ch,encoder_dim,5,padding=2),
                nn.BatchNorm1d(encoder_dim),nn.ReLU(),nn.Dropout(0.2)))
            in_ch=encoder_dim
        self.lstm=nn.LSTM(encoder_dim,encoder_dim//2,batch_first=True,bidirectional=True)

    def forward(self,tokens):
        x=self.embedding(tokens).transpose(1,2)
        for c in self.convs: x=c(x)
        x=x.transpose(1,2)
        x,_=self.lstm(x)
        return x

class Prenet(nn.Module):
    def __init__(self,n_mels,dim):
        super().__init__()
        self.fc1=nn.Linear(n_mels,dim); self.fc2=nn.Linear(dim,dim)
    def forward(self,x):
        x=F.dropout(F.relu(self.fc1(x)),0.5,training=True)
        return F.dropout(F.relu(self.fc2(x)),0.5,training=True)

class Postnet(nn.Module):
    def __init__(self,n_mels,ch=128):
        super().__init__()
        layers=[]; in_ch=n_mels
        for i in range(5):
            out=n_mels if i==4 else ch
            layers.append(nn.Conv1d(in_ch,out,5,padding=2))
            if i<4:
                layers += [nn.BatchNorm1d(out),nn.Tanh(),nn.Dropout(0.2)]
            in_ch=out
        self.net=nn.Sequential(*layers)
    def forward(self,x): return self.net(x)

class Decoder(nn.Module):
    def __init__(self,encoder_dim,decoder_dim,attention_dim,n_mels,prenet_dim,
                 max_decoder_steps=400,gate_threshold=0.5):
        super().__init__()
        self.n_mels=n_mels; self.encoder_dim=encoder_dim; self.decoder_dim=decoder_dim
        self.max_decoder_steps=max_decoder_steps; self.gate_threshold=gate_threshold
        self.prenet=Prenet(n_mels,prenet_dim)
        self.attn_rnn=nn.LSTMCell(prenet_dim+encoder_dim,decoder_dim)
        self.attention=AdaptiveHybridAttention(encoder_dim,decoder_dim,attention_dim)
        self.decoder_rnn=nn.LSTMCell(decoder_dim+encoder_dim,decoder_dim)
        self.mel_proj=nn.Linear(decoder_dim+encoder_dim,n_mels)
        self.gate_proj=nn.Linear(decoder_dim+encoder_dim,1)

    def forward(self,memory,lengths,mel_targets=None):
        B,N,_=memory.shape; dev=memory.device
        mask=torch.arange(N,device=dev).unsqueeze(0)>=lengths.unsqueeze(1)
        ah=torch.zeros(B,self.decoder_dim,device=dev); ac=ah.clone()
        dh=ah.clone(); dc=ah.clone()
        ctx=torch.zeros(B,self.encoder_dim,device=dev)
        prev=torch.zeros(B,N,device=dev); prev[:,0]=1; cum=prev.clone()
        prev_mel=torch.zeros(B,self.n_mels,device=dev)
        T=mel_targets.size(2) if mel_targets is not None else self.max_decoder_steps
        mels=[]; gates=[]; aligns=[]; lambdas=[]
        for t in range(T):
            if mel_targets is not None and t>0: prev_mel=mel_targets[:,:,t-1]
            p=self.prenet(prev_mel)
            ah,ac=self.attn_rnn(torch.cat([p,ctx],-1),(ah,ac))
            a,lam,_,_=self.attention(ah,memory,prev,cum,ctx,mask)
            ctx=torch.bmm(a.unsqueeze(1),memory).squeeze(1)
            dh,dc=self.decoder_rnn(torch.cat([ah,ctx],-1),(dh,dc))
            z=torch.cat([dh,ctx],-1)
            mel=self.mel_proj(z); gate=self.gate_proj(z).squeeze(-1)
            mels.append(mel); gates.append(gate); aligns.append(a); lambdas.append(lam)
            prev_mel=mel; prev=a; cum=cum+a
            if mel_targets is None and bool(torch.all(torch.sigmoid(gate)>self.gate_threshold)):
                break
        return (torch.stack(mels,2),torch.stack(gates,1),
                torch.stack(aligns,1),torch.stack(lambdas,1))

class AdaptiveHybridTacotron(nn.Module):
    def __init__(self,vocab_size=128,embedding_dim=128,encoder_dim=128,
                 decoder_dim=256,attention_dim=128,n_mels=80,prenet_dim=128,
                 postnet_channels=128,max_decoder_steps=400,gate_threshold=0.5):
        super().__init__()
        self.encoder=Encoder(vocab_size,embedding_dim,encoder_dim)
        self.decoder=Decoder(encoder_dim,decoder_dim,attention_dim,n_mels,prenet_dim,
                             max_decoder_steps,gate_threshold)
        self.postnet=Postnet(n_mels,postnet_channels)
    def forward(self,tokens,token_lengths,mel_targets=None):
        mem=self.encoder(tokens)
        mel,gate,align,lambdas=self.decoder(mem,token_lengths,mel_targets)
        return {"mel":mel,"mel_post":mel+self.postnet(mel),"gate":gate,
                "alignments":align,"lambdas":lambdas}
