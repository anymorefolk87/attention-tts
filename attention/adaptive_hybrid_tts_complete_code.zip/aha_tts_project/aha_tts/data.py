import random, torch
from torch.utils.data import Dataset

class SyntheticTTSDataset(Dataset):
    def __init__(self,size=32,vocab_size=128,n_mels=80):
        self.size=size; self.vocab=vocab_size; self.n_mels=n_mels
    def __len__(self): return self.size
    def __getitem__(self,i):
        rng=random.Random(i); n=rng.randint(12,30); m=n*3
        tokens=torch.randint(1,self.vocab,(n,))
        mel=torch.randn(self.n_mels,m)*0.5+torch.linspace(0,1,m)[None,:]
        return {"tokens":tokens,"mel":mel}

def collate_tts(batch):
    B=len(batch); tl=torch.tensor([x["tokens"].numel() for x in batch])
    ml=torch.tensor([x["mel"].size(1) for x in batch])
    T=int(tl.max()); M=int(ml.max()); nm=batch[0]["mel"].size(0)
    tokens=torch.zeros(B,T,dtype=torch.long); mels=torch.zeros(B,nm,M); gates=torch.zeros(B,M)
    for i,x in enumerate(batch):
        n=x["tokens"].numel(); m=x["mel"].size(1)
        tokens[i,:n]=x["tokens"]; mels[i,:,:m]=x["mel"]; gates[i,m-1:]=1
    return {"tokens":tokens,"token_lengths":tl,"mels":mels,"mel_lengths":ml,"gate_targets":gates}
