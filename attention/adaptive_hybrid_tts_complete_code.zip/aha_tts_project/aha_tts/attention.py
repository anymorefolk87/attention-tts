import torch
import torch.nn as nn
import torch.nn.functional as F

class LocationSensitiveAttention(nn.Module):
    def __init__(self, enc_dim, dec_dim, attn_dim, conv_channels=32, kernel_size=31):
        super().__init__()
        self.query_proj = nn.Linear(dec_dim, attn_dim, bias=False)
        self.key_proj = nn.Linear(enc_dim, attn_dim, bias=False)
        self.location_conv = nn.Conv1d(2, conv_channels, kernel_size,
                                       padding=(kernel_size-1)//2, bias=False)
        self.location_proj = nn.Linear(conv_channels, attn_dim, bias=False)
        self.v = nn.Linear(attn_dim, 1, bias=False)

    def forward(self, query, keys, prev_attn, cum_attn, mask=None):
        q = self.query_proj(query).unsqueeze(1)
        k = self.key_proj(keys)
        loc = torch.stack([prev_attn, cum_attn], dim=1)
        loc = self.location_conv(loc).transpose(1,2)
        loc = self.location_proj(loc)
        e = self.v(torch.tanh(q+k+loc)).squeeze(-1)
        if mask is not None:
            e = e.masked_fill(mask, -1e9)
        return F.softmax(e, dim=-1)

class MonotonicPrior(nn.Module):
    def __init__(self, sigma=1.5, forward_step=0.5):
        super().__init__()
        self.sigma=sigma
        self.forward_step=forward_step

    def forward(self, prev_attn, mask=None):
        B,N=prev_attn.shape
        pos=torch.arange(N,device=prev_attn.device,dtype=prev_attn.dtype).unsqueeze(0)
        center=(prev_attn*pos).sum(-1,keepdim=True)+self.forward_step
        logits=-0.5*((pos-center)/self.sigma)**2
        if mask is not None:
            logits=logits.masked_fill(mask,-1e9)
        return F.softmax(logits,dim=-1)

class AdaptiveHybridAttention(nn.Module):
    def __init__(self, enc_dim, dec_dim, attn_dim):
        super().__init__()
        self.location=LocationSensitiveAttention(enc_dim,dec_dim,attn_dim)
        self.monotonic=MonotonicPrior()
        self.gate=nn.Sequential(
            nn.Linear(dec_dim+enc_dim,attn_dim), nn.Tanh(), nn.Linear(attn_dim,1)
        )

    def forward(self, query, keys, prev_attn, cum_attn, prev_context, mask=None):
        a_loc=self.location(query,keys,prev_attn,cum_attn,mask)
        a_mono=self.monotonic(prev_attn,mask)
        lam=torch.sigmoid(self.gate(torch.cat([query,prev_context],dim=-1)))
        a=lam*a_loc+(1-lam)*a_mono
        a=a/a.sum(-1,keepdim=True).clamp_min(1e-8)
        return a,lam.squeeze(-1),a_loc,a_mono
