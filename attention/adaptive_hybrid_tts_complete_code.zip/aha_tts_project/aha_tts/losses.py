import torch
import torch.nn as nn
import torch.nn.functional as F

def guided_attention_loss(a,in_len,out_len,g=0.2):
    total=a.new_tensor(0.0); count=0
    for b in range(a.size(0)):
        n=int(in_len[b]); t=int(out_len[b])
        ii=torch.arange(n,device=a.device).float()/max(n,1)
        tt=torch.arange(t,device=a.device).float()/max(t,1)
        W=1-torch.exp(-((tt[:,None]-ii[None,:])**2)/(2*g*g))
        total += (a[b,:t,:n]*W).mean(); count += 1
    return total/max(count,1)

class TacotronLoss(nn.Module):
    def __init__(self,guided_weight=0.5,gate_weight=1.0):
        super().__init__()
        self.gw=guided_weight; self.sw=gate_weight
    def forward(self,out,mel,gate_t,in_len,out_len):
        l1=F.l1_loss(out["mel"],mel)
        l2=F.l1_loss(out["mel_post"],mel)
        lg=F.binary_cross_entropy_with_logits(out["gate"],gate_t)
        la=guided_attention_loss(out["alignments"],in_len,out_len)
        return {"total":l1+l2+self.sw*lg+self.gw*la,
                "mel":l1.detach(),"mel_post":l2.detach(),
                "gate":lg.detach(),"guided":la.detach()}
