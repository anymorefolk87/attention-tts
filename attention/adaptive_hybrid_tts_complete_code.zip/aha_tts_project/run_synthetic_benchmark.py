import argparse,torch
import torch.nn.functional as F
def metric(path,target):
    peak=path.argmax(-1); d=peak[1:]-peak[:-1]
    return [(d<0).float().mean().item(),(d>3).float().mean().item(),
            (peak.float()-target.float()).abs().mean().item(),
            (-(path*(path+1e-9).log()).sum(-1)).mean().item()]
def trial(seed,noise,T=80,N=40):
    g=torch.Generator().manual_seed(seed); target=torch.floor(torch.linspace(0,N-1,T)).long()
    pos=torch.arange(N).float(); prev=F.one_hot(torch.tensor(0),N).float(); L=[]; H=[]
    for t in range(T):
        logits=-0.5*((pos-target[t].float())/1.7)**2+noise*torch.randn(N,generator=g)
        if torch.rand(1,generator=g).item()<0.18:
            j=int(torch.randint(0,N,(1,),generator=g)); logits[j]+=4+1.5*noise
        loc=F.softmax(logits,-1); c=(prev*pos).sum()+0.5
        mono=F.softmax(-0.5*((pos-c.clamp(0,N-1))/1.5)**2,-1)
        e=-(loc*(loc+1e-9).log()).sum(); lam=torch.clamp(0.2+2.4*torch.exp(-e),0.15,0.85)
        hyb=lam*loc+(1-lam)*mono; hyb/=hyb.sum()
        L.append(loc); H.append(hyb); prev=hyb
    return metric(torch.stack(L),target),metric(torch.stack(H),target)
p=argparse.ArgumentParser(); p.add_argument("--trials",type=int,default=200); p.add_argument("--noise",type=float,default=1.25)
a=p.parse_args(); A=[];B=[]
for s in range(a.trials):
    x,y=trial(s,a.noise); A.append(x);B.append(y)
names=["Backward-step rate","Large-jump rate","Mean abs. error","Attention entropy"]
print(f"{'Metric':<22}{'Location':>14}{'Adaptive Hybrid':>18}")
for i,n in enumerate(names):
    av=sum(x[i] for x in A)/len(A); bv=sum(x[i] for x in B)/len(B)
    print(f"{n:<22}{av:>14.4f}{bv:>18.4f}")
