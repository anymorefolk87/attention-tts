# Adaptive Hybrid Attention TTS Research Project

This repository implements a Tacotron2-style research prototype with an Adaptive Hybrid Attention (AHA) mechanism.

## Proposed model

Text/phoneme tokens
→ Embedding
→ 3-layer convolutional encoder
→ Bidirectional LSTM encoder
→ Adaptive Hybrid Attention
   - Location-sensitive attention branch
   - Monotonic Gaussian prior branch
   - Learned gate λ
→ Autoregressive decoder
→ Mel-spectrogram projection
→ Postnet refinement
→ Neural vocoder (external, e.g. HiFi-GAN) for waveform generation

The attention fusion is:

`alpha = lambda * alpha_location + (1-lambda) * alpha_monotonic`

## Install

`pip install -r requirements.txt`

## Tests

`pytest -q`

## Synthetic alignment benchmark

`python run_synthetic_benchmark.py --trials 200 --noise 1.25`

This benchmark is reproducible and evaluates alignment behavior only.

## Dummy end-to-end training path

`python train.py --epochs 1`

The bundled dataset is synthetic and only validates the training pipeline.

## For publication experiments

Replace `SyntheticTTSDataset` with LJSpeech/VCTK/LibriTTS mel-spectrogram samples while retaining the same dictionary interface. Report real-corpus results separately from the synthetic alignment benchmark.

Recommended metrics:
- CER/WER after ASR
- alignment failure rate
- backward-step rate
- large-jump rate
- long-input failure rate
- MOS/CMOS
- inference latency

Do not describe the bundled synthetic benchmark as a real TTS quality experiment.
