\
from dataclasses import dataclass
from typing import List

from rapidfuzz.fuzz import ratio

from normalization import generate_forms


@dataclass
class Word:
    text: str
    start: float
    end: float
    confidence: float = 1.0


@dataclass
class KeywordHit:
    keyword: str
    start: float
    end: float
    confidence: float
    matched_text: str


def similarity(a: str, b: str) -> float:
    forms_a = generate_forms(a)
    forms_b = generate_forms(b)

    best = 0.0
    for x in forms_a:
        for y in forms_b:
            best = max(best, ratio(x, y) / 100.0)

    return best


def match_keywords(
    words: List[Word],
    keywords: list[dict],
    threshold: float = 0.82,
    max_words_per_keyword: int = 5,
) -> List[KeywordHit]:
    hits = []

    for keyword_info in keywords:
        keyword = keyword_info["text"]

        for i in range(len(words)):
            for length in range(1, max_words_per_keyword + 1):
                j = i + length
                if j > len(words):
                    break

                candidate_words = words[i:j]
                candidate_text = " ".join(w.text for w in candidate_words)
                score = similarity(keyword, candidate_text)

                if score >= threshold:
                    word_conf = sum(w.confidence for w in candidate_words) / len(candidate_words)
                    final_confidence = score * word_conf

                    hits.append(
                        KeywordHit(
                            keyword=keyword,
                            start=candidate_words[0].start,
                            end=candidate_words[-1].end,
                            confidence=final_confidence,
                            matched_text=candidate_text,
                        )
                    )

    return remove_duplicate_hits(hits)


def remove_duplicate_hits(hits: List[KeywordHit]) -> List[KeywordHit]:
    hits = sorted(hits, key=lambda h: h.confidence, reverse=True)
    selected = []

    for hit in hits:
        duplicate = False

        for existing in selected:
            same_keyword = hit.keyword == existing.keyword
            overlap = hit.start < existing.end and hit.end > existing.start

            if same_keyword and overlap:
                duplicate = True
                break

        if not duplicate:
            selected.append(hit)

    return sorted(selected, key=lambda h: h.start)
