\
import re
import unicodedata

from pypinyin import lazy_pinyin
from unidecode import unidecode


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.lower().strip()
    text = re.sub(r"[^\w\s\u4e00-\u9fff]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def contains_chinese(text: str) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def chinese_to_pinyin(text: str) -> str:
    if not contains_chinese(text):
        return normalize_text(text)
    return " ".join(lazy_pinyin(text)).lower()


def romanize(text: str) -> str:
    if contains_chinese(text):
        return chinese_to_pinyin(text)
    return normalize_text(unidecode(text))


def generate_forms(text: str) -> set[str]:
    forms = {
        normalize_text(text),
        romanize(text),
    }
    return {x for x in forms if x}
