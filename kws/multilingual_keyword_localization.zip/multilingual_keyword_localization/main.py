\
import argparse
import json
import sys

import torch
import whisperx

from keyword_matcher import Word, match_keywords


def load_keywords(path: str):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("Keyword file must contain a JSON list.")

    for item in data:
        if not isinstance(item, dict) or "text" not in item:
            raise ValueError("Each keyword must be an object with at least a 'text' field.")

    return data


def transcribe(audio_path: str, model_name: str, batch_size: int):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    compute_type = "float16" if device == "cuda" else "int8"

    print(f"[INFO] Device: {device}")
    print(f"[INFO] Loading model: {model_name}")

    model = whisperx.load_model(
        model_name,
        device=device,
        compute_type=compute_type,
    )

    audio = whisperx.load_audio(audio_path)
    result = model.transcribe(audio, batch_size=batch_size)

    detected_language = result.get("language")
    print(f"[INFO] Primary detected language: {detected_language}")

    if not detected_language:
        return result

    try:
        align_model, metadata = whisperx.load_align_model(
            language_code=detected_language,
            device=device,
        )

        aligned = whisperx.align(
            result["segments"],
            align_model,
            metadata,
            audio,
            device,
            return_char_alignments=False,
        )
        return aligned

    except Exception as exc:
        print(f"[WARN] Alignment unavailable; using ASR timestamps: {exc}")
        return result


def extract_words(result):
    words = []

    if "word_segments" in result:
        source_words = result["word_segments"]
    else:
        source_words = []
        for segment in result.get("segments", []):
            if "words" in segment:
                source_words.extend(segment["words"])

    for item in source_words:
        if "word" not in item or "start" not in item or "end" not in item:
            continue

        confidence = item.get(
            "score",
            item.get("probability", 1.0),
        )

        words.append(
            Word(
                text=item["word"].strip(),
                start=float(item["start"]),
                end=float(item["end"]),
                confidence=float(confidence),
            )
        )

    return words


def main():
    parser = argparse.ArgumentParser(
        description="Multilingual keyword localization from WAV audio using WhisperX."
    )
    parser.add_argument("--wav", required=True, help="Path to WAV/audio file.")
    parser.add_argument("--keywords", required=True, help="Path to keyword JSON file.")
    parser.add_argument("--threshold", type=float, default=0.82, help="Match threshold [0,1].")
    parser.add_argument("--model", default="large-v3", help="Whisper model name.")
    parser.add_argument("--batch-size", type=int, default=8, help="ASR batch size.")
    parser.add_argument("--max-words", type=int, default=5, help="Max ASR words per keyword candidate.")
    parser.add_argument("--output", default="", help="Optional output JSON path.")

    args = parser.parse_args()

    if not (0.0 <= args.threshold <= 1.0):
        print("[ERROR] --threshold must be between 0 and 1.", file=sys.stderr)
        sys.exit(2)

    keywords = load_keywords(args.keywords)
    transcription = transcribe(args.wav, args.model, args.batch_size)
    words = extract_words(transcription)

    print("\n[INFO] Recognized words:")
    for word in words:
        print(f"{word.start:8.3f} - {word.end:8.3f}  {word.text}")

    hits = match_keywords(
        words,
        keywords,
        threshold=args.threshold,
        max_words_per_keyword=args.max_words,
    )

    result = [
        {
            "keyword": hit.keyword,
            "matched_text": hit.matched_text,
            "start": round(hit.start, 3),
            "end": round(hit.end, 3),
            "confidence": round(hit.confidence, 4),
        }
        for hit in hits
    ]

    output_text = json.dumps(result, ensure_ascii=False, indent=2)

    print("\n[INFO] Detected keywords:")
    print(output_text)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output_text)
        print(f"\n[INFO] Saved result to: {args.output}")


if __name__ == "__main__":
    main()
