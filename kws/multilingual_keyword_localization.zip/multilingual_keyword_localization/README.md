\
# Multilingual Keyword Localization

A Python prototype for locating user-provided keywords in existing audio files.

It uses:

1. WhisperX multilingual ASR
2. Word-level alignment where available
3. Multilingual normalization
4. Chinese Pinyin transliteration
5. Fuzzy matching
6. Start/end timestamp extraction

This is designed for cases such as:

- English audio containing Chinese keywords
- Chinese audio containing English words
- Arbitrary keyword lists at inference time
- Single-word and multi-word keyword detection

## Project structure

```text
multilingual_keyword_localization/
├── main.py
├── keyword_matcher.py
├── normalization.py
├── keywords.json
├── requirements.txt
└── README.md
```

## Requirements

Python 3.10 or 3.11 is recommended.

A CUDA-capable GPU is strongly recommended for `large-v3`, although CPU execution is possible with smaller models.

You may also need FFmpeg installed and available on PATH.

## Installation

Create a virtual environment:

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Linux/macOS

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Keyword file

Example `keywords.json`:

```json
[
  {
    "text": "hello",
    "language": "en"
  },
  {
    "text": "北京",
    "language": "zh"
  },
  {
    "text": "谢谢",
    "language": "zh"
  },
  {
    "text": "thank you",
    "language": "en"
  }
]
```

The `language` field is currently informational. Matching is driven by the keyword text and generated normalized/transliterated forms.

## Run

```bash
python main.py \
  --wav test.wav \
  --keywords keywords.json
```

Windows PowerShell:

```powershell
python main.py --wav test.wav --keywords keywords.json
```

Write detections to JSON:

```bash
python main.py \
  --wav test.wav \
  --keywords keywords.json \
  --output result.json
```

Use a smaller Whisper model:

```bash
python main.py \
  --wav test.wav \
  --keywords keywords.json \
  --model medium
```

Adjust the matching threshold:

```bash
python main.py \
  --wav test.wav \
  --keywords keywords.json \
  --threshold 0.75
```

## Output

Example:

```json
[
  {
    "keyword": "北京",
    "matched_text": "Beijing",
    "start": 2.14,
    "end": 2.72,
    "confidence": 0.91
  }
]
```

## Important limitation

This prototype primarily depends on ASR hypotheses.

If a code-switched keyword is completely omitted or badly mistranscribed by ASR, fuzzy textual matching may not recover it.

For a stronger research or production version, add:

- phoneme-level keyword representations
- open-vocabulary acoustic keyword verification
- multilingual speech embeddings
- boundary refinement using frame-level phoneme alignment
- keyword confidence calibration

A recommended next architecture is:

```text
Audio
  ↓
Multilingual ASR
  ↓
Word alignment
  ↓
Text / transliteration / phonetic candidate search
  ↓
Acoustic verification
  ↓
Boundary refinement
  ↓
Keyword + start + end + confidence
```

## Notes about WhisperX

WhisperX versions and installation requirements can change over time. If installation fails, check the current WhisperX installation documentation and its compatible PyTorch/CUDA versions.
