# Local Pronunciation Recovery KWS

This project implements the architecture discussed in the manuscript:

**Primary English ASR + secondary Chinese ASR + local keyword localization + timestamp-guided token replacement.**

The purpose is to recover local names/proper nouns that an English ASR may mistranscribe, for example:

- 北京 -> Beijing
- 沈阳 -> Shenyang
- 长春 -> Changchun

## Architecture

```text
Audio
  |------------------------------|
  v                              v
English ASR (en)             Chinese ASR (zh)
  |                              |
English tokens + time        Chinese tokens + time
  |                              |
  |                       keyword localization
  |                              |
  |                       local keyword spans
  |                              |
  +---------- temporal overlap --+
                 |
                 v
        corrected token list
```

The local ASR path is not used to replace the whole English transcript. It only contributes recognized keywords and their timestamps.

## Why timestamps matter

If Chinese ASR returns:

```text
北  0.800 - 1.020
京  1.020 - 1.360
```

then the recovered keyword is:

```text
北京 / Beijing  0.800 - 1.360
```

Any English token(s) substantially overlapping 0.800-1.360 are suppressed and replaced with canonical token `Beijing`, preserving the Chinese-ASR interval.

## Installation

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
```

Linux/macOS:

```bash
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
```

FFmpeg must be installed and available in PATH.

## Run unit tests without downloading ASR models

```bash
pytest -q
```

The unit tests verify the central research logic using synthetic timestamped ASR tokens.

## Run on audio

```bash
python main.py \
  --wav example.wav \
  --keywords examples/keywords.json \
  --primary-language en \
  --local-language zh \
  --output result.json
```

On Windows:

```powershell
python main.py --wav example.wav --keywords examples/keywords.json --primary-language en --local-language zh --output result.json
```

## Output

`result.json` contains four streams:

- `primary_tokens`: English ASR result
- `local_tokens`: Chinese ASR result
- `keyword_hits`: localized local-name spans
- `corrected_tokens`: final English token list after temporal replacement

Example keyword hit:

```json
{
  "local": "北京",
  "canonical": "Beijing",
  "start": 0.80,
  "end": 1.36,
  "confidence": 0.95,
  "matched_text": "北京",
  "match_score": 1.0,
  "source": "local_asr"
}
```

## Model note

The included adapter uses WhisperX for both paths and **forces different language codes** (`en` and `zh`). This is a practical reproducible baseline. The architecture deliberately separates the ASR adapter from keyword localization/replacement so a dedicated Chinese ASR model can replace the local path later without changing the core algorithm.

For highest timestamp quality, keep WhisperX alignment enabled. If a language-specific aligner is unavailable, the code falls back to timestamps present in the ASR result and records an alignment warning.

## Important research controls

Evaluate at least these systems:

1. English ASR only.
2. English ASR + ordinary text contextual biasing, if available.
3. English ASR + Chinese local-name recovery without timestamp replacement.
4. Proposed dual-ASR timestamp-guided replacement.

Report keyword recall/precision/F1, proper-noun WER or entity error rate, and start/end boundary error in milliseconds.
