import argparse
import json

from local_pronunciation_kws.asr_whisperx import WhisperXConfig
from local_pronunciation_kws.pipeline import LocalPronunciationRecoveryPipeline


def main():
    p = argparse.ArgumentParser(description="Recover local pronunciations with secondary-language ASR and timestamp-guided replacement.")
    p.add_argument("--wav", required=True)
    p.add_argument("--keywords", required=True)
    p.add_argument("--primary-model", default="large-v3")
    p.add_argument("--local-model", default="large-v3")
    p.add_argument("--primary-language", default="en")
    p.add_argument("--local-language", default="zh")
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--threshold", type=float, default=0.84)
    p.add_argument("--max-local-tokens", type=int, default=4)
    p.add_argument("--coverage-threshold", type=float, default=0.45)
    p.add_argument("--iou-threshold", type=float, default=0.20)
    p.add_argument("--output", default="result.json")
    args = p.parse_args()

    primary_cfg = WhisperXConfig(model=args.primary_model, language=args.primary_language, batch_size=args.batch_size)
    local_cfg = WhisperXConfig(model=args.local_model, language=args.local_language, batch_size=args.batch_size)

    pipe = LocalPronunciationRecoveryPipeline(
        primary_cfg,
        local_cfg,
        keyword_threshold=args.threshold,
        max_local_tokens=args.max_local_tokens,
        coverage_threshold=args.coverage_threshold,
        iou_threshold=args.iou_threshold,
    )
    result = pipe.run(args.wav, args.keywords)

    payload = {
        "primary_tokens": [t.to_dict() for t in result.primary_tokens],
        "local_tokens": [t.to_dict() for t in result.local_tokens],
        "keyword_hits": [h.to_dict() for h in result.keyword_hits],
        "corrected_tokens": [t.to_dict() for t in result.corrected_tokens],
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(json.dumps(payload["keyword_hits"], ensure_ascii=False, indent=2))
    print(f"Saved: {args.output}")


if __name__ == "__main__":
    main()
