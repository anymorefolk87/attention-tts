import json
from pathlib import Path

from .types import KeywordSpec, Token


def load_keywords(path: str) -> list[KeywordSpec]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [KeywordSpec(**item) for item in data]


def save_json(path: str, obj) -> None:
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def token_dicts(tokens: list[Token]) -> list[dict]:
    return [t.to_dict() for t in tokens]
