from __future__ import annotations

import gc
from dataclasses import dataclass

import torch
import whisperx

from .types import Token


@dataclass
class WhisperXConfig:
    model: str = "large-v3"
    language: str = "en"
    batch_size: int = 8
    device: str | None = None
    compute_type: str | None = None
    align: bool = True


class WhisperXASR:
    """ASR adapter that can force a language and return aligned token timestamps."""

    def __init__(self, config: WhisperXConfig):
        self.config = config

    def _device(self) -> str:
        return self.config.device or ("cuda" if torch.cuda.is_available() else "cpu")

    def _compute_type(self, device: str) -> str:
        if self.config.compute_type:
            return self.config.compute_type
        return "float16" if device == "cuda" else "int8"

    def transcribe(self, audio_path: str) -> tuple[list[Token], dict]:
        device = self._device()
        compute_type = self._compute_type(device)
        audio = whisperx.load_audio(audio_path)

        model = whisperx.load_model(
            self.config.model,
            device,
            compute_type=compute_type,
            language=self.config.language,
        )
        result = model.transcribe(audio, batch_size=self.config.batch_size)
        del model
        gc.collect()
        if device == "cuda":
            torch.cuda.empty_cache()

        aligned = result
        if self.config.align:
            try:
                align_model, metadata = whisperx.load_align_model(
                    language_code=self.config.language,
                    device=device,
                )
                aligned = whisperx.align(
                    result["segments"],
                    align_model,
                    metadata,
                    audio,
                    device,
                    return_char_alignments=False,
                )
                del align_model
                gc.collect()
                if device == "cuda":
                    torch.cuda.empty_cache()
            except Exception as exc:
                aligned = result.copy()
                aligned["alignment_warning"] = str(exc)

        tokens = self._extract_tokens(aligned)
        return tokens, aligned

    @staticmethod
    def _extract_tokens(result: dict) -> list[Token]:
        raw_words = result.get("word_segments")
        if raw_words is None:
            raw_words = []
            for seg in result.get("segments", []):
                raw_words.extend(seg.get("words", []))

        tokens: list[Token] = []
        for w in raw_words:
            if "start" not in w or "end" not in w:
                continue
            text = str(w.get("word", w.get("text", ""))).strip()
            if not text:
                continue
            conf = float(w.get("score", w.get("probability", 1.0)))
            tokens.append(Token(text=text, start=float(w["start"]), end=float(w["end"]), confidence=conf))
        return tokens
