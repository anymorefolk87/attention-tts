from __future__ import annotations

from .types import KeywordHit, Token


def intersection(a_start: float, a_end: float, b_start: float, b_end: float) -> float:
    return max(0.0, min(a_end, b_end) - max(a_start, b_start))


def token_coverage(token: Token, hit: KeywordHit) -> float:
    """Fraction of an English token covered by a recovered local keyword span."""
    inter = intersection(token.start, token.end, hit.start, hit.end)
    return inter / max(token.duration, 1e-9)


def interval_iou(token: Token, hit: KeywordHit) -> float:
    inter = intersection(token.start, token.end, hit.start, hit.end)
    if inter <= 0:
        return 0.0
    union = max(token.end, hit.end) - min(token.start, hit.start)
    return inter / max(union, 1e-9)


def replace_primary_tokens(
    primary_tokens: list[Token],
    hits: list[KeywordHit],
    coverage_threshold: float = 0.45,
    iou_threshold: float = 0.20,
) -> list[Token]:
    """Replace English-ASR token(s) overlapping each local keyword interval.

    The recovered keyword inherits the local-ASR start/end timestamps. Multiple
    erroneous English tokens can therefore be replaced by one canonical token.
    """
    suppress: set[int] = set()
    for idx, tok in enumerate(primary_tokens):
        for hit in hits:
            if token_coverage(tok, hit) >= coverage_threshold or interval_iou(tok, hit) >= iou_threshold:
                suppress.add(idx)
                break

    output = [tok for idx, tok in enumerate(primary_tokens) if idx not in suppress]
    for hit in hits:
        output.append(
            Token(
                text=hit.canonical,
                start=hit.start,
                end=hit.end,
                confidence=hit.confidence,
                source="local_asr_replacement",
            )
        )
    return sorted(output, key=lambda t: (t.start, t.end))
