from __future__ import annotations

from rapidfuzz.fuzz import ratio

from .normalization import forms
from .types import KeywordHit, KeywordSpec, Token


def _similarity(a: str, b: str) -> float:
    best = 0.0
    for x in forms(a):
        for y in forms(b):
            best = max(best, ratio(x, y) / 100.0)
    return best


def _keyword_score(spec: KeywordSpec, candidate: str) -> float:
    choices = [spec.local, spec.canonical] + list(spec.aliases or [])
    return max(_similarity(choice, candidate) for choice in choices)


def localize_keywords(
    local_tokens: list[Token],
    keywords: list[KeywordSpec],
    threshold: float = 0.84,
    max_tokens: int = 4,
) -> list[KeywordHit]:
    """Find keyword spans in the secondary-language ASR token stream.

    Candidate timestamps are inherited from the first and last local-ASR tokens,
    so a two-character Chinese place name gets a span covering both characters.
    """
    candidates: list[KeywordHit] = []
    for i in range(len(local_tokens)):
        for n in range(1, max_tokens + 1):
            j = i + n
            if j > len(local_tokens):
                break
            span = local_tokens[i:j]
            # Chinese ASR may emit characters with no spaces; evaluate both forms.
            candidate_joined = "".join(t.text for t in span)
            candidate_spaced = " ".join(t.text for t in span)

            for spec in keywords:
                score = max(_keyword_score(spec, candidate_joined), _keyword_score(spec, candidate_spaced))
                if score < threshold:
                    continue
                asr_conf = sum(t.confidence for t in span) / len(span)
                confidence = score * asr_conf
                candidates.append(
                    KeywordHit(
                        local=spec.local,
                        canonical=spec.canonical,
                        start=span[0].start,
                        end=span[-1].end,
                        confidence=confidence,
                        matched_text=candidate_joined,
                        match_score=score,
                    )
                )

    # Non-maximum suppression: keep the best overlapping occurrence for each keyword.
    candidates.sort(key=lambda h: h.confidence, reverse=True)
    kept: list[KeywordHit] = []
    for hit in candidates:
        if any(
            hit.canonical == old.canonical
            and min(hit.end, old.end) > max(hit.start, old.start)
            for old in kept
        ):
            continue
        kept.append(hit)
    return sorted(kept, key=lambda h: h.start)
