from __future__ import annotations

from dataclasses import dataclass

from .asr_whisperx import WhisperXASR, WhisperXConfig
from .io_utils import load_keywords
from .keyword_localizer import localize_keywords
from .replacement import replace_primary_tokens
from .types import KeywordHit, Token


@dataclass
class PipelineResult:
    primary_tokens: list[Token]
    local_tokens: list[Token]
    keyword_hits: list[KeywordHit]
    corrected_tokens: list[Token]


class LocalPronunciationRecoveryPipeline:
    def __init__(
        self,
        primary: WhisperXConfig,
        local: WhisperXConfig,
        keyword_threshold: float = 0.84,
        max_local_tokens: int = 4,
        coverage_threshold: float = 0.45,
        iou_threshold: float = 0.20,
    ):
        self.primary = WhisperXASR(primary)
        self.local = WhisperXASR(local)
        self.keyword_threshold = keyword_threshold
        self.max_local_tokens = max_local_tokens
        self.coverage_threshold = coverage_threshold
        self.iou_threshold = iou_threshold

    def run(self, audio_path: str, keyword_path: str) -> PipelineResult:
        keywords = load_keywords(keyword_path)
        primary_tokens, _ = self.primary.transcribe(audio_path)
        local_tokens, _ = self.local.transcribe(audio_path)
        hits = localize_keywords(
            local_tokens,
            keywords,
            threshold=self.keyword_threshold,
            max_tokens=self.max_local_tokens,
        )
        corrected = replace_primary_tokens(
            primary_tokens,
            hits,
            coverage_threshold=self.coverage_threshold,
            iou_threshold=self.iou_threshold,
        )
        return PipelineResult(primary_tokens, local_tokens, hits, corrected)
