from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class Token:
    text: str
    start: float
    end: float
    confidence: float = 1.0
    source: str = "asr"

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class KeywordSpec:
    local: str
    canonical: str
    language: str = "zh"
    aliases: Optional[list[str]] = None


@dataclass
class KeywordHit:
    local: str
    canonical: str
    start: float
    end: float
    confidence: float
    matched_text: str
    match_score: float
    source: str = "local_asr"

    def to_dict(self) -> dict:
        return asdict(self)
