import re
import unicodedata
try:
    from pypinyin import lazy_pinyin
except ImportError:  # optional at test time; install requirements for full pinyin support
    lazy_pinyin = None
from unidecode import unidecode


def contains_chinese(text: str) -> bool:
    return any("\u4e00" <= c <= "\u9fff" for c in text)


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).lower().strip()
    text = re.sub(r"[^\w\s\u4e00-\u9fff]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def pinyin(text: str) -> str:
    if contains_chinese(text):
        if lazy_pinyin is None:
            return normalize_text(text)
        return " ".join(lazy_pinyin(text)).lower().strip()
    return normalize_text(unidecode(text))


def compact(text: str) -> str:
    return normalize_text(text).replace(" ", "")


def forms(text: str) -> set[str]:
    vals = {
        normalize_text(text),
        compact(text),
        pinyin(text),
        pinyin(text).replace(" ", ""),
        normalize_text(unidecode(text)),
    }
    return {v for v in vals if v}
