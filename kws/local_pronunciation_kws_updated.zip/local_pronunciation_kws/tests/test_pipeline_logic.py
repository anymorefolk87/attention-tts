from local_pronunciation_kws.keyword_localizer import localize_keywords
from local_pronunciation_kws.replacement import replace_primary_tokens
from local_pronunciation_kws.types import KeywordSpec, Token


def test_chinese_character_span_and_replacement():
    primary = [
        Token("I", 0.10, 0.20),
        Token("went", 0.25, 0.55),
        Token("to", 0.58, 0.70),
        Token("paging", 0.82, 1.35, 0.70),
        Token("yesterday", 1.45, 2.00),
    ]
    local = [
        Token("北", 0.80, 1.02, 0.97),
        Token("京", 1.02, 1.36, 0.96),
    ]
    specs = [KeywordSpec(local="北京", canonical="Beijing", aliases=["beijing", "bei jing"])]

    hits = localize_keywords(local, specs, threshold=0.90, max_tokens=2)
    assert len(hits) == 1
    assert hits[0].start == 0.80
    assert hits[0].end == 1.36
    assert hits[0].canonical == "Beijing"

    corrected = replace_primary_tokens(primary, hits)
    texts = [t.text for t in corrected]
    assert "paging" not in texts
    assert "Beijing" in texts
    bj = next(t for t in corrected if t.text == "Beijing")
    assert bj.start == 0.80 and bj.end == 1.36


def test_replaces_multiple_bad_english_tokens():
    primary = [
        Token("from", 0.20, 0.45),
        Token("shen", 0.50, 0.76),
        Token("young", 0.76, 1.12),
        Token("station", 1.20, 1.60),
    ]
    local = [Token("沈", 0.49, 0.77), Token("阳", 0.77, 1.13)]
    specs = [KeywordSpec(local="沈阳", canonical="Shenyang", aliases=["shenyang", "shen yang"])]
    hits = localize_keywords(local, specs, threshold=0.90, max_tokens=2)
    corrected = replace_primary_tokens(primary, hits)
    texts = [t.text for t in corrected]
    assert texts == ["from", "Shenyang", "station"]
